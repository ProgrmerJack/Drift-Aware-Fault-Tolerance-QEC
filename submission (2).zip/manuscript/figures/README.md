# Placeholder for manuscript figures

This directory will contain generated figure files:

## Expected Files

After running the figure generation pipeline:

```
figures/
├── fig1_concept.pdf           # Main text Figure 1
├── fig1_concept.png           # PNG version for review
├── fig2_drift.pdf             # Main text Figure 2
├── fig2_drift.png
├── fig3_syndrome.pdf          # Main text Figure 3
├── fig3_syndrome.png
├── fig4_primary.pdf           # Main text Figure 4 (primary endpoint)
├── fig4_primary.png
├── fig5_generalization.pdf    # Main text Figure 5
├── fig5_generalization.png
└── si/                        # Supplementary figures
    ├── figS1_probe_validation.pdf
    ├── figS2_autocorrelation.pdf
    ├── figS3_decoder_sensitivity.pdf
    └── ...
```

## Figure Generation

Generate all figures:
```bash
python protocol/run_protocol.py --mode=figures
```

Generate individual figure:
```bash
python -c "from src.analysis import generate_figure; generate_figure(1)"
```

## Requirements

- All figures: vector PDF for print, PNG at 300 DPI for review
- Nature Communications limits: ≤10 display items (figures + tables)
- Maximum figure width: 180 mm (full page) or 88 mm (single column)
- Fonts: Helvetica/Arial, 7-10 pt for labels
- Color: colorblind-safe palette (use Okabe-Ito or viridis)

## Style Guide

Per manuscript/figure_manifest.yaml:
- Use consistent axis labels across all panels
- Include statistical annotations (p-values, CIs) on relevant panels
- Error bars represent 95% CI unless otherwise noted
- Significance: * p<0.05, ** p<0.01, *** p<0.001
