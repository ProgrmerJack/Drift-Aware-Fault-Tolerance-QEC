# Cover Letter Template

> **DO NOT COMMIT TO GIT** - Listed in .gitignore
> 
> Replace all [BRACKETED] placeholders before submission.

---

[DATE]

**To the Editors of Nature Communications,**

We submit our manuscript entitled **"Drift-Aware Fault-Tolerance in Quantum Error Correction"** for consideration as an Article in Nature Communications.

## Summary

Quantum error correction (QEC) is essential for achieving fault-tolerant quantum computing. However, a critical gap exists between laboratory demonstrations and real-world deployment: qubit properties on cloud-accessible devices drift on timescales shorter than vendor calibration cycles. Our work addresses this gap with three key contributions:

1. **Empirical characterization of drift:** We demonstrate that qubit properties (T₁, T₂, readout fidelity) drift significantly on sub-calibration timescales, fundamentally reshaping which qubits are optimal for error correction.

2. **Lightweight probe protocol:** We introduce a minimal probe protocol (~30 shots per qubit) that characterizes drift using only ~10 minutes of QPU time—compatible with open-access allocation limits.

3. **Drift-aware fault-tolerance pipeline:** We present an integrated pipeline that dynamically selects qubits and adapts decoder priors based on real-time characterization, achieving a ≥15% reduction in logical error rates with statistical significance (p < 0.01).

## Significance

This work addresses a practical barrier to quantum error correction that has received limited attention: the assumption that vendor calibration data accurately represents device state at experiment time. By demonstrating that this assumption fails and providing a solution compatible with resource-constrained access, we enable researchers without dedicated hardware to perform meaningful fault-tolerance experiments.

Our findings have immediate implications for:
- The ~10,000 researchers using IBM Quantum's Open Plan
- Resource allocation decisions for quantum error correction experiments
- Decoder design for real-world noisy quantum processors

## Reproducibility Commitment

Following best practices for open science:
- All code is available at [REPOSITORY_URL] under MIT license
- All raw and processed data are deposited at Zenodo ([DOI])
- Pre-registered protocol locked before data collection
- Statistical analysis plan registered before unblinding
- All figures include source data files per Nature policy

## Suggested Reviewers

We suggest the following experts in quantum error correction and quantum device physics:

1. **[NAME]**, [Institution] — Expertise in surface code implementations
2. **[NAME]**, [Institution] — Expertise in superconducting qubit characterization
3. **[NAME]**, [Institution] — Expertise in quantum decoder algorithms

## Excluded Reviewers

We request that [NAME] at [Institution] not review this manuscript due to [REASON].

## Statements

- This manuscript has not been published elsewhere and is not under consideration at another journal.
- All authors have approved the manuscript and agree to its submission.
- We have no competing interests to declare.
- All data are available as described in Data Availability statement.
- All code is available as described in Code Availability statement.

We believe this work will be of significant interest to Nature Communications' broad readership in physics, quantum computing, and quantum information science.

Thank you for your consideration.

Sincerely,

**[CORRESPONDING AUTHOR NAME]**  
[TITLE/POSITION]  
[INSTITUTION]  
[EMAIL]  
[PHONE]

---

## Checklist Before Submission

- [ ] Replace all [BRACKETED] placeholders
- [ ] Verify DOI for Zenodo deposit
- [ ] Confirm repository URL is public
- [ ] Verify all author approvals obtained
- [ ] Check competing interests declarations
- [ ] Confirm suggested reviewers have no conflicts
- [ ] Export to PDF for submission portal
