# Nature-Tier Claim Set
## Drift-Aware Fault-Tolerance in Quantum Error Correction

**Paper Target:** Nature Communications / npj Quantum Information  
**Format:** Article (~150-word abstract, ≤5,000-word main text, ≤10 display items)

---

## Core Claims (Scope Lock)

### Claim 1: Drift Invalidates Static Qubit Selection
> **Qubit calibration drift materially changes the "best qubit subset" on cloud QPUs on sub-calibration timescales; backend properties alone are insufficient predictors of QEC performance.**

- **Evidence Required:**
  - Time-series showing T1/T2/gate-error drift exceeding calibration update frequency
  - Ranking instability metrics (Kendall tau) for candidate qubit subsets
  - Head-to-head: property-only vs. probe-refreshed selector accuracy
- **Effect Size Target:** ≥15% ranking disagreement within 4-hour windows
- **Reproducibility:** Demonstrated across ≥3 calibration days, ≥2 backends

### Claim 2: Syndrome Streams Exhibit Non-IID Structure
> **Syndrome measurement streams show statistically significant non-iid structure (temporal bursts, spatial correlations) consistent with correlated error events; these events dominate logical failure tails.**

- **Evidence Required:**
  - Burstiness metrics (Fano factor, inter-event intervals) vs. Poisson null
  - Adjacent-syndrome correlation coefficients
  - Tail analysis: fraction of logical failures attributable to burst events
- **Effect Size Target:** Fano factor ≥1.5 (significantly super-Poissonian)
- **Statistical Test:** Two-sided Kolmogorov-Smirnov vs. iid null, α=0.05

### Claim 3: Drift-Aware Pipeline Reduces Logical Error
> **A drift-aware qubit selection + adaptive-prior decoding pipeline produces a statistically defensible reduction in logical error rate on repetition codes, robust across multiple days and backends.**

- **Evidence Required:**
  - Paired comparison: baseline vs. drift-aware (same decoder)
  - Paired comparison: baseline vs. adaptive-prior (same layout)
  - Full stack vs. baseline with bootstrap 95% CIs
- **Primary Endpoint:** Relative reduction in logical failure probability
- **Effect Size Target:** ≥20% relative improvement, CI excluding zero
- **Robustness:** Effect persists across ≥3 independent calibration days

### Claim 4: Reproducible Open Artifact
> **Complete reproducibility: open dataset + code + exact configurations enable any reader to re-run the full analysis pipeline end-to-end and regenerate all figures.**

- **Evidence Required:**
  - Zenodo-deposited dataset with DOI
  - Tagged code release (v1.0.0) with commit hash
  - `run_protocol.py` regenerates all main figures from raw data
  - Environment file locks all dependencies
- **Verification:** Fresh-machine test passes

---

## Pipeline Diagram (ASCII Reference)

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        DRIFT-AWARE QEC PIPELINE                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │   BACKEND    │    │    PROBE     │    │    QUBIT     │                  │
│  │  PROPERTIES  │───▶│    SUITE     │───▶│   SELECTOR   │                  │
│  │  (Snapshot)  │    │  (30-shot)   │    │  (Adaptive)  │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                   │                   │                          │
│         ▼                   ▼                   ▼                          │
│  ┌──────────────────────────────────────────────────────┐                  │
│  │              REPETITION CODE EXPERIMENT              │                  │
│  │         (d=3,5,7 × r=1,2,3 syndrome rounds)         │                  │
│  └──────────────────────────────────────────────────────┘                  │
│                            │                                               │
│                            ▼                                               │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │   SYNDROME   │    │   DECODER    │    │   LOGICAL    │                  │
│  │   STREAMS    │───▶│  (Adaptive   │───▶│   OUTCOMES   │                  │
│  │              │    │   Prior)     │    │              │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│         │                                       │                          │
│         ▼                                       ▼                          │
│  ┌──────────────────────────────────────────────────────┐                  │
│  │                 DRIFT-ERROR ANALYZER                 │                  │
│  │    (Correlations, Bursts, Threshold Estimation)      │                  │
│  └──────────────────────────────────────────────────────┘                  │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Claim-to-Figure Mapping

| Claim | Primary Figure | Key Panels |
|-------|---------------|------------|
| 1 (Drift invalidates static) | Figure 2 | Drift time-series, ranking instability, selector comparison |
| 2 (Non-iid syndromes) | Figure 3 | Burstiness distribution, tail risk, correlation length |
| 3 (Pipeline reduces error) | Figure 4 | Paired comparisons, full stack vs baseline |
| 4 (Reproducible artifact) | Figure 1 | Pipeline schematic, dataset coverage |

---

## Scope Boundaries (What We Are NOT Claiming)

- ❌ We do NOT claim to demonstrate fault-tolerant computation
- ❌ We do NOT claim surface code threshold improvements (only repetition codes)
- ❌ We do NOT claim real-time adaptive decoding (post-hoc analysis)
- ❌ We do NOT claim to fully characterize the physical source of correlated errors

---

## Pre-Submission Checklist

- [ ] All 4 claims supported by ≥3 independent calibration days
- [ ] Effect sizes with 95% CIs for all primary comparisons
- [ ] Ablation study isolates contribution of each component
- [ ] Protocol.yaml locked before data collection
- [ ] Fresh-machine reproducibility test passed
- [ ] Zenodo DOI minted for dataset
- [ ] Code release tagged (v1.0.0)

---

*Last Updated: 2025-01-XX*  
*Protocol Lock Date: TBD*
